package com.cg.prod.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.prod.beans.Product;

public interface ProductRepository extends JpaRepository<Product, Integer> {

}
