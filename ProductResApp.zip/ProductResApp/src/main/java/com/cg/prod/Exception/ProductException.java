package com.cg.prod.Exception;

public class ProductException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ProductException(String message) {
		super(message);
		
	}

	public ProductException() {
		super();
		// TODO Auto-generated constructor stub
	}

}
