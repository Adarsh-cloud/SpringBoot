package com.cg.prod.service;

import java.util.List;

import com.cg.prod.Exception.ProductException;
import com.cg.prod.beans.Product;

public interface ProductService {
	List<Product> viewAllProduct() throws ProductException;
	List<Product> addProduct(Product prod) throws ProductException;
	List<Product> updateProduct(int id) throws ProductException;*/
	
	List<Product> deleteProductById(int id) throws ProductException;
	Product viewProductBasedOnId(int id) throws ProductException;
	

}
