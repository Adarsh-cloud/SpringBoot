package com.cg.prod.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.prod.Exception.ProductException;
import com.cg.prod.beans.Product;
import com.cg.prod.dao.ProductRepository;
@Service
public class ProductServiceImpl implements ProductService{
	@Autowired
	private ProductRepository productRepository;

	@Override
	public List<Product> viewAllProduct() throws ProductException {
		try {
			return productRepository.findAll();
		} catch (Exception e) {
			throw new ProductException(e.getMessage());
			
		}
		
	}

	@Override
	public List<Product> addProduct(Product prod) throws ProductException {
		if(productRepository.existsById(prod.getId())) {
			throw new ProductException("Product With Id "+prod.getId()+" already exists");
		}
		productRepository.save(prod);
		return viewAllProduct();
	}

	@Override
	public List<Product> updateProduct(int id) throws ProductException {
	
		if(!productRepository.existsById(id)) {
			throw new ProductException("Product With Id"+id+"does not exist");
			
		}
		
		
		
		
	}

	
	@Override
	public List<Product> deleteProductById(int id) throws ProductException {
		if(!productRepository.existsById(id)) {
			throw new ProductException("Product With Id"+id+"does not exists");
		}
		productRepository.deleteById(id);
	  return viewAllProduct();
	}

	@Override
	public Product viewProductBasedOnId(int id) throws ProductException {
		if(!productRepository.existsById(id)) {
			throw new ProductException("Product With Id"+id+"does not exists");
		}
		return productRepository.findById(id).get();
	}

}
