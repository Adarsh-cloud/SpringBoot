package com.cg.course.service;

import java.util.List;

import com.cg.course.Exception.CourseException;
import com.cg.course.bean.Course;

public interface CourseService {
	List<Course> addCourse(Course course) throws CourseException;
	List<Course> deleteCourseDetail(String courseId) throws CourseException;
	List<Course> displayAllCourse() throws CourseException;
	List<Course> updateCourse(Course course) throws CourseException;
	Course getCourseById(String courseid) throws CourseException;
	List<Course> getCourseByMode(String mode) throws CourseException;

}
