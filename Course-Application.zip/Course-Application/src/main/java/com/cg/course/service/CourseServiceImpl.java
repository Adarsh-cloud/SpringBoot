package com.cg.course.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.course.Exception.CourseException;
import com.cg.course.bean.Course;
import com.cg.course.dao.CourseRepository;

@Service
public class CourseServiceImpl implements CourseService{
	@Autowired
	private CourseRepository courseRepository;
	@Override
	public List<Course> addCourse(Course course) throws CourseException {
		if(courseRepository.existsById(course.getCourseId())) {
			throw new CourseException("Course with CourseId"+course.getCourseId()+"already exists");
		}
		courseRepository.save(course);
		return  displayAllCourse();
	}

	@Override
	public List<Course> deleteCourseDetail(String courseId) throws CourseException {
		if(!courseRepository.existsById(courseId)) {
			throw new CourseException("Course with CourseId"+courseId+"does not exists");
		}
		courseRepository.deleteById(courseId);;
		return displayAllCourse();
	}

	@Override
	public List<Course> displayAllCourse() throws CourseException {
		try {
			return courseRepository.findAll();
		} catch (Exception e) {
			throw new CourseException(e.getMessage());
			
		}
		
	}

	@Override
	public Course getCourseById(String courseId) throws CourseException {
		if(!courseRepository.existsById(courseId)) {
			throw new CourseException("Course with Id"+courseId+" does not exists");
		}
		return courseRepository.findById(courseId).get();
	}

	@Override
	public List<Course> getCourseByMode(String mode) throws CourseException {
		return courseRepository.findCourseByMode(mode);
	}

	@Override
	public List<Course> updateCourse(Course course) throws CourseException {
		if(courseRepository.existsById(course.getCourseId())) {
			courseRepository.save(course);
			return displayAllCourse();
		}
		else {
			throw new CourseException("Course with id "+course.getCourseId()+"does not exists");
		}
	}

}
