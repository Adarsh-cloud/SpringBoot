package com.cg.product.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.cg.product.bean.Product;
import com.cg.product.exception.ProductException;
import com.cg.product.service.ProductService;

@RestController
public class ProductController {
		@Autowired
		private ProductService productService;
		
		@RequestMapping("/products")
		public List<Product> getAllProducts()throws ProductException{
			return productService.getAllProducts();
		}
		
		@PostMapping("/products")
		public List<Product> addEmployee(@RequestBody Product product) throws ProductException
		{
			return productService.addProduct(product);
		}
		@DeleteMapping("/products/{id}")
		public List<Product> deleteProduct(@PathVariable int id) throws ProductException
		{
			return productService.deleteProduct(id);
		}
		@GetMapping("/products/{id}")
		public Product getProductById(@PathVariable int id) throws ProductException{
			return productService.getProductById(id);
		}
		@GetMapping("/products/category")
		public List<Product> getProductByCategory(@RequestParam String category) throws ProductException{
			return productService.getProductByCategory(category);
		}
		@PutMapping("/products/update/{id}")
		public List<Product> updateProduct(@RequestBody Product product, @PathVariable int id) throws ProductException {
			return productService.updateProduct(product,id);
		}
		 @ExceptionHandler({ProductException.class}) 
		 public ResponseEntity<String> handleError(Exception ex){  
			 return new ResponseEntity<String>(ex.getMessage(),HttpStatus.NOT_FOUND);
		 }
		  
}
