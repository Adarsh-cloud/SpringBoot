package com.cg.product.exception;

public class ProductException extends Exception{

	private static final long serialVersionUID = 1L;
	public ProductException() {
		super();
	}
	public ProductException(String msg) {
		super(msg);
	}
}
