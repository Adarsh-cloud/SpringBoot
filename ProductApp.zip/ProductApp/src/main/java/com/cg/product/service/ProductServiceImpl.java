package com.cg.product.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.product.bean.Product;
import com.cg.product.dao.ProductRepository;
import com.cg.product.exception.ProductException;

@Service
public class ProductServiceImpl implements ProductService{
	@Autowired
	private ProductRepository productRepository;
	@Override
	public List<Product> getAllProducts() throws ProductException {
		try {
			return productRepository.findAll();
		} catch (Exception e) {
			throw new ProductException(e.getMessage());
		}
	}

	@Override
	public List<Product> addProduct(Product product) throws ProductException {
		if(productRepository.existsById(product.getId())) {
			throw new ProductException("Employee with id "+product.getId()+"alreadyt exist");
		}
		productRepository.save(product);
		return getAllProducts();
	}

	@Override
	public Product getProductById(int id) throws ProductException {
		if(!productRepository.existsById(id))
		{
			throw new ProductException("Product with id "+id+" does not exist");
		}
		return productRepository.findById(id).get();
	}

	@Override
	public List<Product> deleteProduct(int id) throws ProductException {
		if(!productRepository.existsById(id))
		{
			throw new ProductException("Product with id "+id+" does not exist");
		}
		productRepository.deleteById(id);
		return getAllProducts();
	}

	
	  @Override public List<Product> updateProduct(Product product,int id) throws ProductException
	  { 
		  if(productRepository.existsById(id)) 
		  { 
			  Product product2 = getProductById(product.getId());
			  product2.setPrice(product.getPrice());
			  product2.setQuantity(product.getQuantity());
			  productRepository.save(product2); 
			  return getAllProducts();
		  }
		  throw new ProductException("Product with id "+id+" does not exist");
	  
	  }
	 

	@Override
	public List<Product> getProductByCategory(String category) throws ProductException {
		return productRepository.findProductByCategory(category);
	}

}
