package com.cg.product.service;

import java.util.List;

import com.cg.product.bean.Product;
import com.cg.product.exception.ProductException;


public interface ProductService {
	List<Product> getAllProducts()throws ProductException;
	List<Product> addProduct(Product product)throws ProductException;
	Product getProductById(int id)throws ProductException;
	List<Product> deleteProduct(int id)throws ProductException;
	List<Product> updateProduct(Product product,int id)throws ProductException;
	List<Product> getProductByCategory(String category)throws ProductException;
}
