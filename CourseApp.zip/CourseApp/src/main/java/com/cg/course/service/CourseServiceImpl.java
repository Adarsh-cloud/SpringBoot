package com.cg.course.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.course.bean.Course;
import com.cg.course.dao.CourseRepository;
import com.cg.course.exception.CourseException;

@Service
public class CourseServiceImpl implements CourseService{
	@Autowired
	private CourseRepository courseRepository;
	@Override
	public List<Course> getAllCourses() throws CourseException {
		try {
			return courseRepository.findAll();
		} catch (Exception e) {
			throw new CourseException(e.getMessage());
		}
	}

	@Override
	public List<Course> addCourse(Course course) throws CourseException {
		if(courseRepository.existsById(course.getCourseId()))
		{
			throw new CourseException("Course with id "+course.getCourseId()+"alreadyt exist");
		}
		courseRepository.save(course);
		return getAllCourses();
	}

	@Override
	public Course getCourseById(String courseId) throws CourseException {
		if(!courseRepository.existsById(courseId))
		{
			throw new CourseException("Course with id "+courseId+" does not exist");
		}
		return courseRepository.findById(courseId).get();
	}

	@Override
	public List<Course> deleteCourse(String courseId) throws CourseException {
		if(!courseRepository.existsById(courseId))
		{
			throw new CourseException("Course with id "+courseId+" does not exist");
		}
		courseRepository.deleteById(courseId);
		return getAllCourses();
	}

	@Override
	public List<Course> updateCourse(Course course) throws CourseException {
		if(courseRepository.existsById(course.getCourseId())) 
			{			  
			courseRepository.save(course); 
			  return getAllCourses();
		  }
		  throw new CourseException("Course with id "+course.getCourseId()+" does not exist");
	}

	@Override
	public List<Course> getCourseByMode(String mode) throws CourseException {
		return courseRepository.findCourseByMode(mode);
	}

}
