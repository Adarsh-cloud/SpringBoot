package com.cg.course.service;

import java.util.List;

import com.cg.course.bean.Course;
import com.cg.course.exception.CourseException;

public interface CourseService {
	List<Course> getAllCourses()throws CourseException;
	List<Course> addCourse(Course course)throws CourseException;
	Course getCourseById(String courseId)throws CourseException;
	List<Course> deleteCourse(String courseId)throws CourseException;
	List<Course> updateCourse(Course course)throws CourseException;
	List<Course> getCourseByMode(String mode)throws CourseException;
}
